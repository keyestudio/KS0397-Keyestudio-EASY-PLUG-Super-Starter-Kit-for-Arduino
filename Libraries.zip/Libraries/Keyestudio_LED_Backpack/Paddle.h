

class Paddle{
  public:
  int pos;
  int size;

  void moveLeft();
  void moveRight();
  };
